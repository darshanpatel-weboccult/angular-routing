import { Component } from '@angular/core';

@Component({
  selector: 'app-toggl-report',
  templateUrl: './toggl-report.component.html',
  styleUrls: ['./toggl-report.component.scss']
})
export class TogglReportComponent {

}
