import { Component } from '@angular/core';

@Component({
  selector: 'app-extra-staffing',
  templateUrl: './extra-staffing.component.html',
  styleUrls: ['./extra-staffing.component.scss']
})
export class ExtraStaffingComponent {

}
