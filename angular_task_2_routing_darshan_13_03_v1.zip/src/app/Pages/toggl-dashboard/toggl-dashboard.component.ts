import { Component } from '@angular/core';

@Component({
  selector: 'app-toggl-dashboard',
  templateUrl: './toggl-dashboard.component.html',
  styleUrls: ['./toggl-dashboard.component.scss']
})
export class TogglDashboardComponent {

}
