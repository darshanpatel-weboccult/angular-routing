import { Component } from '@angular/core';

@Component({
  selector: 'app-holiday-management',
  templateUrl: './holiday-management.component.html',
  styleUrls: ['./holiday-management.component.scss']
})
export class HolidayManagementComponent {

}
