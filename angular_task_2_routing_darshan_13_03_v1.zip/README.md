# Angular Task : Angular Routing

### Task : Create 3 Level routing for UI same as WebOccult HRMS portal

### Concepts
- Routing
- Nested Routing
- Lazy Loading

### Preview

![](./README_ASSETS/Angular_Routing_Img1.png)
![](./README_ASSETS/Angular_Routing_Img2.png)
![](./README_ASSETS/Angular_Routing_Img3.png)